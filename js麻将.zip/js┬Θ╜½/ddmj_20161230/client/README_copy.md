# hello-world
Hello world new project template.
2016-09-16 23:28:35.559 SCMJ-mobile[5764:6847046] *** Assertion failure in void _UIApplicationMainPreparations(int, char **, NSString *__strong, NSString *__strong)(), /BuildRoot/Library/Caches/com.apple.xbs/Sources/UIKit/UIKit-3512.60.12/UIApplication.m:3702
2016-09-16 23:28:35.561 SCMJ-mobile[5764:6847046] *** Terminating app due to uncaught exception 'NSInternalInconsistencyException', reason: 'Unable to instantiate the UIApplication subclass instance. No class named NSApplication is loaded.'
*** First throw call stack:
(0x183c16db0 0x18327bf80 0x183c16c80 0x18459c1c0 0x189023b5c 0x188de2054 0x1000befc0 0x1836928b8)
libc++abi.dylib: terminating with uncaught exception of type NSException